def postProcessAngleThrottle(angle, throttle):
  return (angle, throttle)
