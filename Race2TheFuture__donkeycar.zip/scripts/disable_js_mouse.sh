xinput set-prop "Sony PLAYSTATION(R)3 Controller" "Device Enabled" 0

